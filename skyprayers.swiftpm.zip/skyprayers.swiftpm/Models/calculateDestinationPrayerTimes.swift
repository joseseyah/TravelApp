//
//  File.swift
//  TravelApp
//
//  Created by Joseph Hayes on 06/02/2025.
//

import Foundation
import CoreLocation

//func calculateDestinationPrayerTimes(latitude: Double, longitude: Double, arrivalDate: Date) -> [String: String] {
//    let destinationCoordinates = Coordinates(latitude: latitude, longitude: longitude)
//    
//    // Convert the date to the correct format
//    let calendar = Calendar(identifier: .gregorian)
//    let dateComponents = calendar.dateComponents([.year, .month, .day], from: arrivalDate)
//    
//    // Configure the calculation method (adjust as needed)
//    var params = CalculationMethod.muslimWorldLeague.params
//    params.adjustments.fajr = 2
//    params.adjustments.isha = 2
//    
//    // Get prayer times
//    guard let prayerTimes = PrayerTimes(coordinates: destinationCoordinates, date: dateComponents, calculationParameters: params) else {
//        return [:]
//    }
//    
//    // Format times into a readable dictionary
//    let formatter = DateFormatter()
//    formatter.timeStyle = .short
//    var formattedPrayerTimes: [String: String] = [:]
//    
//    for prayer in Prayer.allCases {
//        let time = prayerTimes.time(for: prayer)
//        formattedPrayerTimes[prayerName(for: prayer)] = formatter.string(from: time)
//    }
//    
//    return formattedPrayerTimes
//}
