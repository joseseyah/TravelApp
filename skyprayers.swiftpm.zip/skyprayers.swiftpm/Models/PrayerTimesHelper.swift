//
//  PrayerTimesHelper.swift
//  TravelApp
//
//  Created by Joseph Hayes on 30/11/2024.
//

import Foundation

class PrayerTimesHelper {
    static func calculatePrayerTimes(latitude: Double, longitude: Double, date: Date) -> PrayerTimes? {
        let coordinates = Coordinates(latitude: latitude, longitude: longitude)
        let params = CalculationMethod.moonsightingCommittee.params
        let today = Calendar.current.dateComponents([.year, .month, .day], from: date)
        
        return PrayerTimes(coordinates: coordinates, date: today, calculationParameters: params)
    }
}

