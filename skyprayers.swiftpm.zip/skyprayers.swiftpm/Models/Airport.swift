import Foundation
import CoreLocation

struct Airport: Identifiable, Decodable {
    var id: String { code }
    let code: String
    let lat: String?
    let lon: String?
    let name: String
    let city: String?
    let state: String?
    let country: String?
    let tz: String?
    let runway_length: String?
    let elev: String?
    let icao: String?
    let direct_flights: String?
    let carriers: String?
    let type: String? // To filter out non-airport types

    // MARK: - Computed Properties

    /// Converts latitude to a `Double?`
    var latitude: Double? {
        guard let latString = lat, let latValue = Double(latString) else { return nil }
        return latValue
    }

    /// Converts longitude to a `Double?`
    var longitude: Double? {
        guard let lonString = lon, let lonValue = Double(lonString) else { return nil }
        return lonValue
    }

    /// Returns the time zone as `TimeZone?`
    var timeZone: TimeZone? {
        guard let timeZoneID = tz else { return nil }
        return TimeZone(identifier: timeZoneID)
    }

    /// Checks if the airport is a valid commercial airport
    var isValidAirport: Bool {
        return type?.lowercased() == "airports"
    }
}
