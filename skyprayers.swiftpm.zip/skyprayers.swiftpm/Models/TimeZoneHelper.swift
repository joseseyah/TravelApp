//
//  TimeZoneHelper.swift
//  TravelApp
//
//  Created by Joseph Hayes on 30/11/2024.
//

import CoreLocation

func getTimeZone(for city: String, completion: @escaping (TimeZone?) -> Void) {
    let geocoder = CLGeocoder()
    geocoder.geocodeAddressString(city) { placemarks, error in
        if let error = error {
            print("Error geocoding city: \(error.localizedDescription)")
            completion(nil)
            return
        }
        
        guard let placemark = placemarks?.first,
              let location = placemark.location else {
            print("No location found for city: \(city)")
            completion(nil)
            return
        }
        
        // Get time zone from location
        if let timeZone = placemark.timeZone {
            completion(timeZone)
        } else {
            print("Time zone not found for city: \(city)")
            completion(nil)
        }
    }
}
