import Foundation

struct TripStorage {
    static func saveTrips(_ trips: [Trip]) {
        if let data = try? JSONEncoder().encode(trips) {
            UserDefaults.standard.set(data, forKey: "trips")
        }
    }

    static func loadTrips() -> [Trip] {
        if let data = UserDefaults.standard.data(forKey: "trips"),
           let trips = try? JSONDecoder().decode([Trip].self, from: data) {
            return trips
        }
        return []
    }
}

