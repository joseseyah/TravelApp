import SwiftUI
import CoreLocation

class AirportLoader: ObservableObject {
    static let shared = AirportLoader()
    @Published var airports: [Airport] = []
    
    private init() {
        loadAirports()
    }
    
    //load airport from json file
    func loadAirports() {
        guard let url = Bundle.main.url(forResource: "airports", withExtension: "json") else {
            print("Failed to locate json file")
            return
        }
        do {
            let data = try Data(contentsOf: url)
            let decodedAirports = try JSONDecoder().decode([Airport].self, from: data)

            DispatchQueue.main.async {
                self.airports = decodedAirports.filter { airport in
                    airport.type == "Airports" && !(airport.name.isEmpty)
                }
                print("Loaded Successfully -> \(self.airports.count) airports.")
            }
        } catch {
            print("JSON Decoding failure: \(error.localizedDescription)")
        }
    }

    // get airport name by copde
    func getAirport(by code: String) -> Airport? {
        return airports.first { $0.code == code }
    }
}
