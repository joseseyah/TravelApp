import CoreLocation
import SwiftUI

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let locationManager = CLLocationManager()
    private let geocoder = CLGeocoder()
    
    @Published var userLocation: CLLocation? = nil
    @Published var cityName: String? = nil

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            userLocation = location
            print("Location update to: \(location.coordinate.latitude), \(location.coordinate.longitude)")
            fetchCityName(from: location)
            locationManager.stopUpdatingLocation()
        }
    }
    
    private func fetchCityName(from location: CLLocation) {
        geocoder.reverseGeocodeLocation(location) { [weak self] placemarks, error in
            guard let self = self else { return }
            if let placemark = placemarks?.first {
                self.cityName = placemark.locality ?? "unknown loc"
                print("City: \(self.cityName ?? "unknown loc")")
            } else if let error = error {
                print("Cannot get city name: \(error.localizedDescription)")
                self.cityName = "unknown loc"
            }
        }
    }
}
