import SwiftUI

//all colours defined in the project
extension Color {
    static let backgroundColor = Color(red: 210/255, green: 230/255, blue: 250/255)
    static let boxBackgroundColor = Color(red: 24/255, green: 62/255, blue: 108/255)
    static let highlightColor = Color(red: 93/255, green: 170/255, blue: 168/255)
    static let pageBackgroundColor = Color(red: 240/255, green: 248/255, blue: 255/255)
    static let secondaryColor = Color(red: 44/255, green: 70/255, blue: 99/255)
}
