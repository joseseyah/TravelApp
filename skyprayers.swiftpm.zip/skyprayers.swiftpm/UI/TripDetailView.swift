import SwiftUI
import CoreLocation

struct TripDetailView: View {
    var trip: Trip
    let prayerTimes: PrayerTimes

    @State private var inFlightPrayers: [String] = []

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                airportInfoView()
                flightTimingsView()
                prayerTimesView()
                travelPrayerOptionsView()
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 16)
        }
        .background(Color.backgroundColor.edgesIgnoringSafeArea(.all))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("Trip Details")
                    .font(.title2)
                    .bold()
                    .foregroundColor(Color.highlightColor)
            }
        }
        .onAppear {
            determineInFlightPrayers(trip: trip)
        }
    }
    
    private func convertToTimeZone(date: Date, timeZone: TimeZone) -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        formatter.timeZone = timeZone

        let dateString = formatter.string(from: date)
        return formatter.date(from: dateString) ?? date
    }


    private func getOriginPrayerTimes(for trip: Trip) -> PrayerTimes? {
        let calendar = Calendar.current
        let departureDateComponents = calendar.dateComponents([.year, .month, .day], from: trip.departureDate)

        var calculationParams = CalculationMethod.moonsightingCommittee.params
        calculationParams.madhab = .shafi

        let originCoords = trip.coordinatesForOrigin()!
        let originCoordinates = Coordinates(latitude: originCoords.latitude, longitude: originCoords.longitude)

        return PrayerTimes(
            coordinates: originCoordinates,
            date: departureDateComponents,
            calculationParameters: calculationParams
        )
    }

    private func determineInFlightPrayers(trip: Trip) {
        guard let destinationCoords = trip.coordinatesForDestination() else { return }
        let calendar = Calendar.current
        let arrivalTime = trip.arrivalTime
        let departureTime = trip.departureTime

        var inFlightPrayerNames: [String] = []
        
        // Determine if the flight is overnight
        let isOvernight = !calendar.isDate(departureTime, inSameDayAs: arrivalTime)
        
        if isOvernight {
            let arrivalDateComponents = calendar.dateComponents([.year, .month, .day], from: trip.arrivalDate)
            var calculationParams = CalculationMethod.moonsightingCommittee.params
            calculationParams.madhab = .shafi
            let destinationCoordinates = Coordinates(latitude: destinationCoords.latitude, longitude: destinationCoords.longitude)
            
            guard let destinationPrayerTimes = PrayerTimes(
                coordinates: destinationCoordinates,
                date: arrivalDateComponents,
                calculationParameters: calculationParams
            ) else { return }
            
            let destFajrStart = destinationPrayerTimes.fajr
            let destFajrEnd = calendar.date(byAdding: .minute, value: 90, to: destFajrStart)!
            
            
            if arrivalTime >= destFajrStart {
                inFlightPrayerNames.append("Fajr")
                print("Including Fajr (overnight): destination Fajr start \(destFajrStart), arrival \(arrivalTime)")
            } else {
                print("Skipping Fajr (overnight): flight arrives before destination Fajr starts (\(destFajrStart))")
            }
            
            let destinationPrayerDict: [String: Date] = [
                "Dhuhr": destinationPrayerTimes.dhuhr,
                "Asr": destinationPrayerTimes.asr,
                "Maghrib": destinationPrayerTimes.maghrib,
                "Isha": destinationPrayerTimes.isha
            ]
            for prayerName in ["Dhuhr", "Asr", "Maghrib", "Isha"] {
                if let prayerTime = destinationPrayerDict[prayerName] {
                    if prayerTime <= arrivalTime {
                        inFlightPrayerNames.append(prayerName)
                        print("Including \(prayerName) at \(prayerTime)")
                    } else {
                        print("Skipping \(prayerName): \(prayerTime) is after arrival (\(arrivalTime))")
                    }
                }
            }
        } else {
            // For same-day flights, Fajr is determined using the origin’s times.
            guard let originPrayerTimes = getOriginPrayerTimes(for: trip) else { return }
            let originFajrStart = originPrayerTimes.fajr
            let originFajrEnd = calendar.date(byAdding: .minute, value: 90, to: originFajrStart)!
            
            // Include Fajr only if the flight departs before Fajr ends at origin.
            if departureTime < originFajrEnd {
                inFlightPrayerNames.append("Fajr")
                print("Including Fajr (same day): departure \(departureTime) is before origin Fajr end \(originFajrEnd)")
            } else {
                print("Skipping Fajr (same day): departure \(departureTime) is after origin Fajr end \(originFajrEnd)")
            }
            
            // For the other prayers, still use the destination’s arrival-day times.
            let arrivalDateComponents = calendar.dateComponents([.year, .month, .day], from: trip.arrivalDate)
            var calculationParams = CalculationMethod.moonsightingCommittee.params
            calculationParams.madhab = .shafi
            let destinationCoordinates = Coordinates(latitude: destinationCoords.latitude, longitude: destinationCoords.longitude)
            
            guard let destinationPrayerTimes = PrayerTimes(
                coordinates: destinationCoordinates,
                date: arrivalDateComponents,
                calculationParameters: calculationParams
            ) else { return }
            
            let destinationPrayerDict: [String: Date] = [
                "Dhuhr": destinationPrayerTimes.dhuhr,
                "Asr": destinationPrayerTimes.asr,
                "Maghrib": destinationPrayerTimes.maghrib,
                "Isha": destinationPrayerTimes.isha
            ]
            for prayerName in ["Dhuhr", "Asr", "Maghrib", "Isha"] {
                if let prayerTime = destinationPrayerDict[prayerName] {
                    if prayerTime <= arrivalTime {
                        inFlightPrayerNames.append(prayerName)
                        print("Including \(prayerName) at \(prayerTime)")
                    } else {
                        print("Skipping \(prayerName): \(prayerTime) is after arrival (\(arrivalTime))")
                    }
                }
            }
        }
        
        inFlightPrayers = inFlightPrayerNames
        print("Selected Prayers: \(inFlightPrayers)")
    }

    // Fetch destination prayer times dynamically
    private func getDestinationPrayerTimes(for trip: Trip) -> [PrayerDisplay]? {
        let calendar = Calendar.current

        let departureDateComponents = calendar.dateComponents([.year, .month, .day], from: trip.departureDate)
        let arrivalDateComponents = calendar.dateComponents([.year, .month, .day], from: trip.arrivalDate)

        var calculationParams = CalculationMethod.moonsightingCommittee.params
        calculationParams.madhab = .shafi

        guard let destinationCoords = trip.coordinatesForDestination() else {
            print("ERROR: Could not retrieve destination coordinates.")
            return nil
        }
        
        let destinationCoordinates = Coordinates(latitude: destinationCoords.latitude, longitude: destinationCoords.longitude)

        guard let departurePrayerTimes = PrayerTimes(
            coordinates: destinationCoordinates,
            date: departureDateComponents,
            calculationParameters: calculationParams
        ) else {
            print("ERROR: Could not fetch prayers for departure date (\(trip.departureDate))")
            return nil
        }

        
        guard let arrivalPrayerTimes = PrayerTimes(
            coordinates: destinationCoordinates,
            date: arrivalDateComponents,
            calculationParameters: calculationParams
        ) else {
            print("ERROR: Could not fetch prayers for arrival date (\(trip.arrivalDate))")
            return nil
        }

        let formatter = DateFormatter()
        formatter.timeStyle = .short
        formatter.timeZone = trip.arrivalTimeZone()

        
        return [
            PrayerDisplay(name: "Fajr", time: formatter.string(from: departurePrayerTimes.fajr)),
            PrayerDisplay(name: "Dhuhr", time: formatter.string(from: departurePrayerTimes.dhuhr)),
            PrayerDisplay(name: "Asr", time: formatter.string(from: departurePrayerTimes.asr)),
            PrayerDisplay(name: "Maghrib", time: formatter.string(from: departurePrayerTimes.maghrib)),
            PrayerDisplay(name: "Isha", time: formatter.string(from: departurePrayerTimes.isha)),
            PrayerDisplay(name: "Fajr", time: formatter.string(from: arrivalPrayerTimes.fajr)),
            PrayerDisplay(name: "Dhuhr", time: formatter.string(from: arrivalPrayerTimes.dhuhr)),
            PrayerDisplay(name: "Asr", time: formatter.string(from: arrivalPrayerTimes.asr)),
            PrayerDisplay(name: "Maghrib", time: formatter.string(from: arrivalPrayerTimes.maghrib)),
            PrayerDisplay(name: "Isha", time: formatter.string(from: arrivalPrayerTimes.isha))
        ]
    }


    // MARK: - In-flight Prayer Times View
    private func prayerTimesView() -> some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Prayers to Complete Before Landing")
                    .font(.title3)
                    .bold()
                    .foregroundColor(Color.white)

                Divider()
                    .background(Color.gray.opacity(0.3))

                if inFlightPrayers.isEmpty {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(Color.green)
                        Text("No prayers required during the flight.")
                            .font(.subheadline)
                            .foregroundColor(Color.white)
                    }
                } else {
                    ForEach(inFlightPrayers, id: \.self) { prayer in
                        HStack {
                            Text(prayer)
                                .font(.subheadline)
                                .bold()
                                .foregroundColor(Color.white)
                        }
                    }
                }
            }
            .padding(20)
            .background(RoundedRectangle(cornerRadius: 18).fill(Color.boxBackgroundColor))
            .shadow(radius: 6)
        }
    }
    
    private func travelPrayerOptionsView() -> some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Combine and Shorten Prayers During Travel")
                    .font(.title3)
                    .bold()
                    .foregroundColor(Color.white)

                Divider()
                    .background(Color.gray.opacity(0.3))

                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(Color.green)
                        Text("Combine Dhuhr and Asr")
                            .font(.subheadline)
                            .foregroundColor(Color.white)
                    }

                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(Color.green)
                        Text("Combine Maghrib and Isha")
                            .font(.subheadline)
                            .foregroundColor(Color.white)
                    }

                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(Color.green)
                        Text("Shorten Dhuhr, Asr, and Isha to 2 rakats instead of 4")
                            .font(.subheadline)
                            .foregroundColor(Color.white)
                    }
                }
            }
            .padding(20)
            .background(RoundedRectangle(cornerRadius: 18).fill(Color.boxBackgroundColor))
            .shadow(radius: 6)
        }
    }



    private func airportInfoView() -> some View {
        let originAirport = AirportLoader.shared.getAirport(by: trip.originCode)?.name ?? trip.originCode
        let destinationAirport = AirportLoader.shared.getAirport(by: trip.destinationCode)?.name ?? trip.destinationCode

        return ZStack {
            RoundedRectangle(cornerRadius: 18)
                .fill(LinearGradient(
                    gradient: Gradient(colors: [
                        Color.boxBackgroundColor.opacity(0.95),
                        Color.boxBackgroundColor.opacity(0.85)
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ))
                .shadow(color: Color.black.opacity(0.15), radius: 6, x: 0, y: 4)

            VStack(spacing: 12) {
                HStack {
                    Image(systemName: "airplane.departure")
                        .font(.title2)
                        .foregroundColor(Color.white)
                    VStack(alignment: .leading) {
                        Text("From")
                            .font(.caption)
                            .foregroundColor(Color.white)
                        Text(originAirport)
                            .font(.headline)
                            .bold()
                            .foregroundColor(Color.white)
                    }
                    Spacer()
                }

                HStack {
                    RoundedRectangle(cornerRadius: 2)
                        .frame(height: 2)
                        .foregroundColor(Color.highlightColor)
                        .padding(.horizontal, 10)
                    Image(systemName: "arrow.right")
                        .foregroundColor(Color.white)
                        .font(.title2)
                        .padding(.horizontal, 4)
                    RoundedRectangle(cornerRadius: 2)
                        .frame(height: 2)
                        .foregroundColor(Color.highlightColor)
                        .padding(.horizontal, 10)
                }

                HStack {
                    Image(systemName: "airplane.arrival")
                        .font(.title2)
                        .foregroundColor(Color.white)
                    VStack(alignment: .leading) {
                        Text("To")
                            .font(.caption)
                            .foregroundColor(Color.white)
                        Text(destinationAirport)
                            .font(.headline)
                            .bold()
                            .foregroundColor(Color.white)
                    }
                    Spacer()
                }
            }
            .padding(20)
        }
        .frame(height: 150)
    }

    private func flightTimingsView() -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18)
                .fill(LinearGradient(gradient: Gradient(colors: [Color.boxBackgroundColor, Color.boxBackgroundColor.opacity(0.85)]),
                                     startPoint: .topLeading,
                                     endPoint: .bottomTrailing))
                .shadow(radius: 6)

            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Departure")
                        .font(.caption)
                        .foregroundColor(Color.white)
                    
                    Text("\(trip.departureTime, formatter: originTimeFormatter)")
                        .font(.title2)
                        .bold()
                        .foregroundColor(Color.white)
                }
                Spacer()

                VStack {
                    Image(systemName: "airplane.departure")
                        .font(.title2)
                        .foregroundColor(Color.highlightColor)
                        .padding(10)
                        .background(Circle().fill(Color.boxBackgroundColor.opacity(0.5)))
                }
                Spacer()

                VStack(alignment: .trailing, spacing: 4) {
                    Text("Arrival")
                        .font(.caption)
                        .foregroundColor(Color.white)
                    // arrival time to be formatted in the origin timezone.
                    Text("\(trip.arrivalTime, formatter: originTimeFormatter)")
                        .font(.title2)
                        .bold()
                        .foregroundColor(Color.white)
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
        }
        .frame(height: 120)
    }

    private var originTimeFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .none
        formatter.timeStyle = .short
        formatter.timeZone = trip.departureTimeZone()
        return formatter
    }
}
