import SwiftUI
import CoreLocation

struct AddTripView: View {
    
    @StateObject private var airportLoader = AirportLoader.shared
    @State private var selectedOriginAirport: Airport?
    @State private var selectedDestinationAirport: Airport?
    @State private var departureDate = Date()
    @State private var departureTime = Date()
    @State private var arrivalDate = Date()
    @State private var arrivalTime = Date()
    @State private var showSaveConfirmation = false
    @State private var isSaving = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var isSelectingOrigin = false
    @State private var isSelectingDestination = false
    
    @Environment(\.presentationMode) var presentationMode
    var saveTrip: (Trip) -> Void
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.backgroundColor.edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 0) {
                    
                    Text("Add Trip")
                        .font(.title)
                        .foregroundColor(Color.secondaryColor)
                        .padding(.top, 16)
                        .padding(.bottom, 8)

                    
                    Form {
                        Section(header: Text("Trip Details")
                            .foregroundColor(Color.highlightColor)) {
                                
                               
                                Button(action: { isSelectingOrigin.toggle() }) {
                                    HStack {
                                        Text(selectedOriginAirport?.name ?? "Select Origin Airport")
                                            .foregroundColor(selectedOriginAirport == nil ? .gray : .primary)
                                        Spacer()
                                        Image(systemName: "airplane.departure")
                                            .foregroundColor(.gray)
                                    }
                                }
                                .sheet(isPresented: $isSelectingOrigin) {
                                    AirportSearchView(
                                        airports: airportLoader.airports,
                                        onSelect: { airport in
                                            selectedOriginAirport = airport
                                            isSelectingOrigin = false
                                        }
                                    )
                                }
                                
                                Button(action: { isSelectingDestination.toggle() }) {
                                    HStack {
                                        Text(selectedDestinationAirport?.name ?? "Select Destination Airport")
                                            .foregroundColor(selectedDestinationAirport == nil ? .gray : .primary)
                                        Spacer()
                                        Image(systemName: "airplane.arrival")
                                            .foregroundColor(.gray)
                                    }
                                }
                                .sheet(isPresented: $isSelectingDestination) {
                                    AirportSearchView(
                                        airports: airportLoader.airports,
                                        onSelect: { airport in
                                            selectedDestinationAirport = airport
                                            isSelectingDestination = false
                                        }
                                    )
                                }
                                
                                DatePicker("Departure Date", selection: $departureDate, displayedComponents: .date)
                                DatePicker("Departure Time", selection: $departureTime, displayedComponents: .hourAndMinute)
                                DatePicker("Arrival Date", selection: $arrivalDate, displayedComponents: .date)
                                DatePicker("Arrival Time", selection: $arrivalTime, displayedComponents: .hourAndMinute)
                            }
                        
                        Section {
                            Button(action: {
                                if validateInputs() {
                                    isSaving = true
                                    saveTripDetails()
                                } else {
                                    showAlert = true
                                }
                            }) {
                                Text(isSaving ? "Saving..." : "Save Trip")
                                    .frame(maxWidth: .infinity)
                                    .padding()
                                    .background(isSaving ? Color.gray : Color.highlightColor)
                                    .foregroundColor(.pageBackgroundColor)
                                    .cornerRadius(8)
                            }
                            .disabled(isSaving)
                        }
                    }
                    .background(Color.backgroundColor)
                    .scrollContentBackground(.hidden)
                }
            }
            .navigationBarTitle("", displayMode: .inline)
            .alert(isPresented: $showAlert) {
                Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        }
    }
    
    func validateInputs() -> Bool {
        guard selectedOriginAirport != nil else {
            alertMessage = "Please select an origin airport."
            return false
        }
        guard selectedDestinationAirport != nil else {
            alertMessage = "Please select a destination airport."
            return false
        }
        return true
    }
    
    func saveTripDetails() {
        guard let originAirport = selectedOriginAirport,
              let destinationAirport = selectedDestinationAirport else {
            return
        }

        let combinedDeparture = combineDateWithTime(date: departureDate, time: departureTime)
        let combinedArrival = combineDateWithTime(date: arrivalDate, time: arrivalTime)

        let newTrip = Trip(
            originCode: originAirport.code,
            destinationCode: destinationAirport.code,
            originLatitude: Double(originAirport.lat ?? "0.0") ?? 0.0,
            originLongitude: Double(originAirport.lon ?? "0.0") ?? 0.0,
            destinationLatitude: Double(destinationAirport.lat ?? "0.0") ?? 0.0,
            destinationLongitude: Double(destinationAirport.lon ?? "0.0") ?? 0.0,
            departureDate: combinedDeparture,
            departureTime: combinedDeparture,
            arrivalDate: combinedArrival,
            arrivalTime: combinedArrival
        )

        saveTrip(newTrip)
        isSaving = false
        showSaveConfirmation = true

        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            presentationMode.wrappedValue.dismiss()
        }
    }

    private func combineDateWithTime(date: Date, time: Date) -> Date {
        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.year, .month, .day], from: date)
        let timeComponents = calendar.dateComponents([.hour, .minute], from: time)

        var mergedComponents = DateComponents()
        mergedComponents.year = dateComponents.year
        mergedComponents.month = dateComponents.month
        mergedComponents.day = dateComponents.day
        mergedComponents.hour = timeComponents.hour
        mergedComponents.minute = timeComponents.minute

        return calendar.date(from: mergedComponents) ?? date
    }

}
