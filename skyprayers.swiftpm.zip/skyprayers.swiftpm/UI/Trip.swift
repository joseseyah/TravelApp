import Foundation
import CoreLocation

struct Trip: Codable, Equatable, Identifiable, Hashable {
    var id = UUID()
    var originCode: String
    var destinationCode: String
    var originLatitude: Double?
    var originLongitude: Double?
    var destinationLatitude: Double?
    var destinationLongitude: Double?
    var departureDate: Date
    var departureTime: Date
    var arrivalDate: Date
    var arrivalTime: Date

    func coordinatesForOrigin() -> CLLocationCoordinate2D? {
        guard let lat = originLatitude, let lon = originLongitude else { return nil }
        return CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }

    func coordinatesForDestination() -> CLLocationCoordinate2D? {
        guard let lat = destinationLatitude, let lon = destinationLongitude else { return nil }
        return CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }

    func departureTimeZone() -> TimeZone {
        return AirportLoader.shared.getAirport(by: originCode)?.timeZone ?? TimeZone.current
    }

    func arrivalTimeZone() -> TimeZone {
        return AirportLoader.shared.getAirport(by: destinationCode)?.timeZone ?? TimeZone.current
    }

}

