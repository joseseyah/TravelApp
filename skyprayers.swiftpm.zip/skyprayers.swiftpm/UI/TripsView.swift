import SwiftUI

struct TripsView: View {
    @Binding var trips: [Trip]
    @Binding var pastTrips: [Trip]
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.backgroundColor
                    .edgesIgnoringSafeArea(.all)
                
                VStack(alignment: .leading) {
                    Text("My Trips")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.highlightColor)
                        .padding(.horizontal)
                        .padding(.top)
                    
                    let activeTrips = trips.filter { $0.arrivalDate > Date() }
                    
                    if activeTrips.isEmpty {
                        Spacer()
                        Text("No Upcoming Trips")
                            .font(.title)
                            .foregroundColor(.highlightColor)
                            .padding()
                            .frame(maxWidth: .infinity)
                        Spacer()
                    } else {
                        ScrollView {
                            ForEach(activeTrips, id: \.id) { trip in 
                                NavigationLink(destination: TripDetailViewWrapper(trip: trip)) {
                                    TripBoxView(trip: trip)
                                }
                                .padding(.horizontal)
                                .padding(.vertical, 5)
                            }
                        }
                    }
                }
            }
            .onAppear {
                moveCompletedTrips()
            }
        }
    }
    
    func moveCompletedTrips() {
        let completedTrips = trips.filter { $0.arrivalDate <= Date() }
        pastTrips.append(contentsOf: completedTrips)
        trips.removeAll(where: { $0.arrivalDate <= Date() })
    }
}

struct TripDetailViewWrapper: View {
    var trip: Trip
    
    var body: some View {
        guard let latitude = trip.originLatitude, let longitude = trip.originLongitude else {
            return AnyView(Text("Unable to calculate prayer times.")
                .foregroundColor(.red)
            )
        }
        
        guard let prayerTimes = PrayerTimesHelper.calculatePrayerTimes(
            latitude: latitude,
            longitude: longitude,
            date: trip.departureDate
        ) else {
            return AnyView(Text("Prayer times not available.")
                .foregroundColor(.red)
            )
        }
        
        return AnyView(TripDetailView(trip: trip, prayerTimes: prayerTimes))
    }
}
