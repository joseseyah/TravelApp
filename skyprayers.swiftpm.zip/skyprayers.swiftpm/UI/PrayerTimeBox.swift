import Foundation
import SwiftUI

struct PrayerTimeBox: View {
    var prayerName: String
    var time: String
    
    var body: some View {
        HStack {
            Text(prayerName)
                .font(.title3)
                .fontWeight(.bold)
                .foregroundColor(.highlightColor)
            
            Spacer()
            
            Text(time)
                .font(.title3)
                .fontWeight(.medium)
                .foregroundColor(.highlightColor)
        }
        .padding(12)
        .background(Color.boxBackgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.2), radius: 6, x: 0, y: 4)
    }
}

