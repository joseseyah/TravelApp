import SwiftUI

struct DestinationPrayerTimesView: View {
    @Binding var trips: [Trip]
    @State private var sortedTrips: [Trip] = []
    @State private var selectedTimeZone: TimeZoneOption = .destination

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Title Section
                    Text("Destination Prayer Times")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.highlightColor)
                        .padding(.horizontal)

                    if sortedTrips.isEmpty {
                        VStack {
                            RoundedRectangle(cornerRadius: 15)
                                .fill(Color.pageBackgroundColor)
                                .frame(height: 150)
                                .overlay(
                                    Text("No upcoming trips.")
                                        .foregroundColor(.secondaryColor)
                                        .font(.headline)
                                )
                                .shadow(radius: 3)
                                .padding(.horizontal)
                        }
                    } else {
                        ForEach(sortedTrips, id: \.id) { trip in
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    Text("\(trip.destinationCode)")
                                        .font(.title3)
                                        .foregroundColor(.highlightColor)
                                    Spacer()
                                    Text(formattedDate(trip.arrivalDate))
                                        .font(.subheadline)
                                        .foregroundColor(.secondaryColor)
                                }

                                Divider().background(Color.highlightColor)

                                // Segmented control for switching time zones
                                Picker("", selection: $selectedTimeZone) {
                                    Text("Time from \(trip.originCode)")
                                        .tag(TimeZoneOption.origin)
                                    Text("Time at \(trip.destinationCode)")
                                        .tag(TimeZoneOption.destination)
                                }
                                .pickerStyle(SegmentedPickerStyle())
                                .padding(.horizontal)

                                // display prayer times dynamically based on selected time zone
                                if let prayerTimes = getPrayerTimes(for: trip, useOriginTimeZone: selectedTimeZone == .origin) {
                                    ForEach(prayerTimes, id: \.name) { prayer in
                                        HStack {
                                            Text(prayer.name)
                                                .font(.body)
                                                .foregroundColor(.white)
                                            Spacer()
                                            Text(prayer.time)
                                                .font(.body)
                                                .foregroundColor(.white)
                                                .bold()
                                        }
                                        .padding(.horizontal)
                                        .padding(.vertical, 10)
                                        .background(Color.boxBackgroundColor)
                                        .cornerRadius(10)
                                    }
                                } else {
                                    Text("Unable to calculate prayer times.")
                                        .foregroundColor(.red)
                                        .padding(.top, 5)
                                }
                            }
                            .padding()
                            .background(Color.pageBackgroundColor)
                            .cornerRadius(15)
                            .shadow(radius: 3)
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            .background(Color.backgroundColor.edgesIgnoringSafeArea(.all))
        }
        .onAppear {
            sortTripsByArrivalDate()
        }
    }

    private func sortTripsByArrivalDate() {
        sortedTrips = trips.filter { $0.arrivalDate > Date() }.sorted { $0.arrivalDate < $1.arrivalDate }
    }

    private func getPrayerTimes(for trip: Trip, useOriginTimeZone: Bool) -> [PrayerDisplay]? {
        guard let coordinates = trip.coordinatesForDestination() else {
            return nil
        }

        let calendar = Calendar.current
        let dateComponents = calendar.dateComponents([.year, .month, .day], from: trip.arrivalDate)

        var calculationParams = CalculationMethod.moonsightingCommittee.params
        calculationParams.madhab = .shafi

        guard let prayerTimes = PrayerTimes(
            coordinates: Coordinates(latitude: coordinates.latitude, longitude: coordinates.longitude),
            date: dateComponents,
            calculationParameters: calculationParams
        ) else {
            return nil
        }

        let formatter = DateFormatter()
        formatter.timeStyle = .short

        formatter.timeZone = useOriginTimeZone ? trip.departureTimeZone() : trip.arrivalTimeZone()

        return [
            PrayerDisplay(name: "Fajr", time: formatter.string(from: prayerTimes.fajr)),
            PrayerDisplay(name: "Dhuhr", time: formatter.string(from: prayerTimes.dhuhr)),
            PrayerDisplay(name: "Asr", time: formatter.string(from: prayerTimes.asr)),
            PrayerDisplay(name: "Maghrib", time: formatter.string(from: prayerTimes.maghrib)),
            PrayerDisplay(name: "Isha", time: formatter.string(from: prayerTimes.isha))
        ]
    }

    private func formattedDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}

enum TimeZoneOption: String {
    case origin
    case destination
}

struct PrayerDisplay: Identifiable {
    let id = UUID()
    let name: String
    let time: String
}
