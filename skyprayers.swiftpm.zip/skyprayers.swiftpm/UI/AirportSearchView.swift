import SwiftUI

struct AirportSearchView: View {
    let airports: [Airport]
    @State private var searchQuery = ""
    let onSelect: (Airport) -> Void
    
    var filteredAirports: [Airport] {
        airports.filter { airport in
            let query = searchQuery.trimmingCharacters(in: .whitespaces)
            return airport.name.localizedCaseInsensitiveContains(query) ||
                   (airport.country?.localizedCaseInsensitiveContains(query) ?? false) ||
                   (airport.city?.localizedCaseInsensitiveContains(query) ?? false)
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.backgroundColor.edgesIgnoringSafeArea(.all)
                
                VStack {
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        
                        TextField("Search Airports, Cities, or Countries...", text: $searchQuery)
                            .foregroundColor(Color.white)
                            .padding(.vertical, 10)
                            .frame(maxWidth: .infinity)  // Ensure valid width
                            .background(Color.boxBackgroundColor.opacity(0.8))
                            .cornerRadius(10)
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.boxBackgroundColor))
                    .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 3)
                    .padding(.horizontal)
                    
                    // **List of Airports**
                    if !filteredAirports.isEmpty {
                        ScrollView {
                            ForEach(filteredAirports, id: \.code) { airport in
                                Button(action: { onSelect(airport) }) {
                                    HStack {
                                        VStack(alignment: .leading) {
                                            Text(airport.name)
                                                .font(.title3)
                                                .fontWeight(.bold)
                                                .foregroundColor(.white)
                                            
                                            Text("\(airport.city ?? "Unknown"), \(airport.country ?? "Unknown")")
                                                .font(.body)
                                                .foregroundColor(Color.gray.opacity(0.8))
                                        }
                                        Spacer()
                                        Image(systemName: "airplane.circle.fill")
                                            .foregroundColor(.highlightColor)
                                            .font(.title2)
                                    }
                                    .padding()
                                    .background(Color.boxBackgroundColor.opacity(0.9))
                                    .cornerRadius(12)
                                    .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 3)
                                    .frame(maxWidth: .infinity)
                                }
                                .padding(.horizontal)
                                .padding(.vertical, 5)
                            }
                        }
                    } else {
                        Text("No results found")
                            .font(.headline)
                            .foregroundColor(.secondaryColor)
                            .padding()
                    }
                }
                .padding(.top, 10)
            }
            .navigationTitle("Search Airport")
        }
    }
}
