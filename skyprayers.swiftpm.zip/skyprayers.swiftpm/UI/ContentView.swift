import SwiftUI

struct ContentView: View {
    @State private var trips: [Trip] = []  
    @State private var pastTrips: [Trip] = []
    
    var body: some View {
        TabView {
            // Home Tab
            HomeView(trips: $trips, pastTrips: $pastTrips)
                .tabItem {
                    Image(systemName: "globe.asia.australia")
                    Text("Home")
                }
            
            // All Trips
            TripsView(trips: $trips, pastTrips: $pastTrips)
                .tabItem {
                    Image(systemName: "airplane")
                    Text("Trips")
                }
            
            // Travel Duas
            TravelTipsView()
                .tabItem {
                    Image(systemName: "book")
                    Text("Travel Tips")
                }
            
            // Destination Prayer Times
            DestinationPrayerTimesView(trips: $trips)
                .tabItem {
                    Image(systemName: "moon")
                    Text("Prayer Times")
                }
        }
        .accentColor(.highlightColor)
        .onAppear(perform: loadTrips)
        .onChange(of: trips, perform: { _ in
            saveTrips() 
        })
    }
    
    // Save trips
    func saveTrips() {
        if let encoded = try? JSONEncoder().encode(trips) {
            UserDefaults.standard.set(encoded, forKey: "savedTrips")
        }
    }
    
    // Load trips
    func loadTrips() {
        if let savedData = UserDefaults.standard.data(forKey: "savedTrips") {
            if let decodedTrips = try? JSONDecoder().decode([Trip].self, from: savedData) {
                trips = decodedTrips
            }
        }
    }
}
