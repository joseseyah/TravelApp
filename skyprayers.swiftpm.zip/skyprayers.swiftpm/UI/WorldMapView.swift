import SwiftUI
import MapKit

struct WorldMapView: UIViewRepresentable {
    var trips: [Trip]

    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator
        mapView.showsUserLocation = false
        mapView.isZoomEnabled = true
        mapView.isScrollEnabled = true
        mapView.isRotateEnabled = true
        mapView.mapType = .satelliteFlyover

        let initialCamera = MKMapCamera(
            lookingAtCenter: CLLocationCoordinate2D(latitude: 0, longitude: 0),
            fromDistance: 50000000,
            pitch: 60,
            heading: 0
        )
        mapView.setCamera(initialCamera, animated: true)

        updateMapView(mapView)
        return mapView
    }

    func updateUIView(_ mapView: MKMapView, context: Context) {
        mapView.removeOverlays(mapView.overlays)
        mapView.removeAnnotations(mapView.annotations)
        updateMapView(mapView)
    }

    private func updateMapView(_ mapView: MKMapView) {
        for trip in trips {
            if let originAirport = AirportLoader.shared.getAirport(by: trip.originCode),
               let destinationAirport = AirportLoader.shared.getAirport(by: trip.destinationCode),
               let originLat = originAirport.lat,
               let originLon = originAirport.lon,
               let destLat = destinationAirport.lat,
               let destLon = destinationAirport.lon,
               let originLatitude = Double(originLat),
               let originLongitude = Double(originLon),
               let destinationLatitude = Double(destLat),
               let destinationLongitude = Double(destLon) {

                let originCoord = CLLocationCoordinate2D(latitude: originLatitude, longitude: originLongitude)
                let destinationCoord = CLLocationCoordinate2D(latitude: destinationLatitude, longitude: destinationLongitude)

                let polyline = MKPolyline(coordinates: [originCoord, destinationCoord], count: 2)
                mapView.addOverlay(polyline)

                let originMarker = MKPointAnnotation()
                originMarker.coordinate = originCoord
                originMarker.title = originAirport.name
                mapView.addAnnotation(originMarker)

                let destinationMarker = MKPointAnnotation()
                destinationMarker.coordinate = destinationCoord
                destinationMarker.title = destinationAirport.name
                mapView.addAnnotation(destinationMarker)
            }
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: WorldMapView

        init(_ parent: WorldMapView) {
            self.parent = parent
        }

        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            if let polyline = overlay as? MKPolyline {
                let renderer = MKPolylineRenderer(polyline: polyline)
                renderer.strokeColor = .blue
                renderer.lineWidth = 3
                return renderer
            }
            return MKOverlayRenderer(overlay: overlay)
        }
    }
}
