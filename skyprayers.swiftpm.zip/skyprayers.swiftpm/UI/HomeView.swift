import SwiftUI
import CoreLocation

struct HomeView: View {
    @Binding var trips: [Trip]
    @Binding var pastTrips: [Trip]
    
    @State private var showMap = false
    @State private var showAddTripView = false
    @StateObject private var locationManager = LocationManager()
    @State private var prayerTimes: PrayerTimes?
    
    var body: some View {
        ZStack {
            Color.backgroundColor
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                // Add Trip Button
                HStack {
                    Text("Add Trip")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(Color.highlightColor)
                        .onTapGesture { showAddTripView = true }
                    Spacer()
                    Image(systemName: "plus.circle.fill")
                        .foregroundColor(Color.highlightColor)
                        .font(.title)
                        .onTapGesture { showAddTripView = true }
                }
                .padding([.top, .leading, .trailing])
                
                Spacer()
                
               
                VStack {
                    Image(systemName: "globe.europe.africa.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                        .foregroundColor(.highlightColor)
                        .onTapGesture { showMap = true }
                    
                    Text("My Journeys")
                        .font(.headline)
                        .foregroundColor(.highlightColor)
                        .padding(.top, 8)
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.highlightColor, lineWidth: 2)
                        .background(RoundedRectangle(cornerRadius: 12).fill(Color.boxBackgroundColor))
                )
                .padding(.horizontal)
                .padding(.top, 40)
                
                Spacer()
                
                // Prayer Times Section
                Text(locationManager.cityName ?? "Fetching location... Prayer Times")
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.highlightColor)
                    .padding(.bottom, 10)
                
                VStack(alignment: .leading, spacing: 16) {
                    if let times = prayerTimes {
                        PrayerTimeBox(prayerName: "Fajr", time: formatTime(times.fajr))
                        PrayerTimeBox(prayerName: "Dhuhr", time: formatTime(times.dhuhr))
                        PrayerTimeBox(prayerName: "Asr", time: formatTime(times.asr))
                        PrayerTimeBox(prayerName: "Maghrib", time: formatTime(times.maghrib))
                        PrayerTimeBox(prayerName: "Isha", time: formatTime(times.isha))
                    } else {
                        Text("Fetching prayer times...")
                            .foregroundColor(.highlightColor)
                    }
                }
                .padding(.horizontal)
                
                Spacer()
            }
            .padding()
        }
        .sheet(isPresented: $showMap) {
            WorldMapContainerView(isPresented: $showMap, trips: trips)
        }
        .sheet(isPresented: $showAddTripView) {
            AddTripView { newTrip in
                trips.append(newTrip)
            }
        }
        .onChange(of: locationManager.userLocation) { location in
            if let location = location {
                prayerTimes = PrayerTimesHelper.calculatePrayerTimes(
                    latitude: location.coordinate.latitude,
                    longitude: location.coordinate.longitude,
                    date: Date()
                )
            }
        }
    }
    
    func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}
