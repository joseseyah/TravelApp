//
//  TravelAppApp.swift
//  TravelApp
//
//  Created by Joseph Hayes on 15/10/2024.
//

import SwiftUI

@main
struct TravelAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
