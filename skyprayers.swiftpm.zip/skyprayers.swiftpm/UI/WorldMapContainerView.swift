import SwiftUI

struct WorldMapContainerView: View {
    @Binding var isPresented: Bool
    var trips: [Trip]

    var body: some View {
        ZStack {
            WorldMapView(trips: trips)
                .edgesIgnoringSafeArea(.all)

            VStack {
                HStack {
                    Spacer()
                    Button(action: {
                        isPresented = false
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 30))
                            .foregroundColor(.white)
                            .padding()
                    }
                }
                Spacer()
            }
        }
    }
}
