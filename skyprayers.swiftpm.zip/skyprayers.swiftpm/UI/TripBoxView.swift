import SwiftUI
import Foundation

struct TripBoxView: View {
    var trip: Trip
    
    var body: some View {
        let destinationAirport = AirportLoader.shared.getAirport(by: trip.destinationCode)
        let destinationName = destinationAirport?.name ?? trip.destinationCode
        
        HStack {
            Image(systemName: "airplane")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(Color.highlightColor)
                .cornerRadius(8)
                .padding(.trailing, 10)
            
            VStack(alignment: .leading) {
                Text("More details")
                    .font(.subheadline)
                    .foregroundColor(.green)
                
                Text(destinationName)
                    .font(.title3)
                    .fontWeight(.bold)
                    .foregroundColor(Color.highlightColor)
                
                Text("\(trip.departureDate, formatter: tripDateFormatter)")
                    .font(.subheadline)
                    .foregroundColor(Color.white)
            }
            Spacer()
        }
        .padding()
        .background(Color.boxBackgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 3)
    }
}

let tripDateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    formatter.timeStyle = .none
    return formatter
}()
