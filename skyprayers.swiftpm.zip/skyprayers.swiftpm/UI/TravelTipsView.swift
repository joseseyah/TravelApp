import SwiftUI

struct TravelTipsView: View {
    @State private var isTasbihSheetPresented = false
    
    var body: some View {
        ZStack {
            // Solid background color
            Color.backgroundColor
                .edgesIgnoringSafeArea(.all)
            
            ScrollView {
                VStack(spacing: 30) {
                    // Title
                    HStack {
                        Text("Travel Duas")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(Color.highlightColor)
                        
                        Spacer()
                        
                        Button(action: {
                            isTasbihSheetPresented.toggle()
                        }) {
                            Image(systemName: "list.bullet")
                                .font(.title3) // Decreased size
                                .padding(8) // Smaller padding
                                .background(Color.highlightColor)
                                .foregroundColor(Color.backgroundColor)
                                .clipShape(Circle())
                        }
                        .sheet(isPresented: $isTasbihSheetPresented) {
                            TasbihCounterView()
                        }
                    }
                    .padding(.top, 20)
                    
                    // Dua Cards
                    DuaCardView(
                        title: "Dua for Travel",
                        arabic: "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ",
                        translation: "Glory to Him who has subjected this to us, and we could never have it [by our efforts]. And to our Lord, surely, we will return."
                    )
                    
                    DuaCardView(
                        title: "Dua for Leaving Home",
                        arabic: "بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
                        translation: "In the name of Allah, I place my trust in Allah, and there is no power nor might except with Allah."
                    )
                    
                    DuaCardView(
                        title: "Dua for Safety During Travel",
                        arabic: "اللّهُمَّ أَنْتَ الصَّاحِبُ فِي السَّفَرِ، وَالْخَلِيفَةُ فِي الأَهْلِ",
                        translation: "O Allah, You are the Companion in travel, and the Guardian of the family."
                    )
                }
                .padding(.horizontal, 20)
            }
        }
    }
}


struct TasbihCounterView: View {
    @State private var counter = 0
    @State private var checkedItems: [String: Bool] = [
        "Subhanallah": false,
        "Alhamdulilah": false,
        "Allahu Akbar": false,
        "La ilaha illallah": false,
        "Astaghfirullah": false,
        "Bismillah": false,
        "Alhamdulillah Rabbil Alamin": false,
        "Ya Rahman Ya Raheem": false,
    ]
    
    var body: some View {
        ZStack {
            Color.backgroundColor
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                RoundedRectangle(cornerRadius: 15)
                    .fill(Color.boxBackgroundColor)
                    .shadow(radius: 5)
                    .overlay(
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Dhikr Checklist")
                                .font(.headline)
                                .foregroundColor(Color.highlightColor)
                                .padding()
                            
                            ForEach(Array(checkedItems.keys), id: \ .self) { key in
                                HStack {
                                    Button(action: { checkedItems[key]?.toggle() }) {
                                        Image(systemName: checkedItems[key]! ? "checkmark.square.fill" : "square")
                                            .foregroundColor(Color.highlightColor)
                                    }
                                    Text(key)
                                        .foregroundColor(Color.pageBackgroundColor)
                                }
                                .padding(.horizontal)
                            }
                        }
                        .padding()
                    )
                    .frame(width: 300)
                    .padding()
                
                Text("Tasbih Counter")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(Color.highlightColor)
                    .padding()
                
                Text("\(counter)")
                    .font(.system(size: 80, weight: .bold))
                    .foregroundColor(Color.highlightColor)
                
                HStack(spacing: 30) {
                    Button(action: { counter += 1 }) {
                        Text("+1")
                            .font(.title)
                            .frame(width: 80, height: 80)
                            .background(Color.highlightColor)
                            .foregroundColor(Color.pageBackgroundColor)
                            .clipShape(Circle())
                    }
                    
                    Button(action: { counter = 0 }) {
                        Text("Reset")
                            .font(.title)
                            .frame(width: 80, height: 80)
                            .background(Color.boxBackgroundColor)
                            .foregroundColor(Color.pageBackgroundColor)
                            .clipShape(Circle())
                    }
                }
                .padding()
            }
        }
    }
}

struct DuaCardView: View {
    let title: String
    let arabic: String
    let translation: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.headline)
                .fontWeight(.bold)
                .foregroundColor(Color.highlightColor)

            Text(arabic)
                .font(.title3)
                .multilineTextAlignment(.leading)
                .foregroundColor(Color.pageBackgroundColor)

            Text(translation)
                .font(.body)
                .foregroundColor(Color.pageBackgroundColor)
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 150) // Ensuring consistent card size
        .background(Color.boxBackgroundColor)
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 3)
    }
}
